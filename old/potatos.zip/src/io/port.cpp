#include <io/port.h>

io::Port::Port(uint16 port) :
    _port(port) {
}
